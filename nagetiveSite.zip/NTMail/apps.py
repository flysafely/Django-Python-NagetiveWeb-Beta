from django.apps import AppConfig


class NTMailConfig(AppConfig):
    name = 'NTMail'
    verbose_name='邮件配置中心'