from django.apps import AppConfig


class NtwebsiteConfig(AppConfig):
    name = 'NTWebsite'
