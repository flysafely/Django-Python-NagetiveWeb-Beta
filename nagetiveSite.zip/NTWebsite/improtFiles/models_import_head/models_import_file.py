from django.contrib import admin
from django.db.models import Q
from django.db.models import F
from django.db.models.query import QuerySet
from django.db.models import Model
from NTWebsite.models import *
from NTNotification.models import *
from NTMail.models import *
