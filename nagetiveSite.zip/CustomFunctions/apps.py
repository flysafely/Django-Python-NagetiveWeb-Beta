from django.apps import AppConfig


class CustomfunctionsConfig(AppConfig):
    name = 'CustomFunctions'
