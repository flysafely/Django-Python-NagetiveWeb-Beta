from django.apps import AppConfig


class NTNotificationConfig(AppConfig):
    name = 'NTNotification'
    verbose_name='通知中心'
